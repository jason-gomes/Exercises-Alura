alert('Welcome to this simple exercise ');
let username = prompt('insira seu nome')
diaSemana = prompt(`que dia é hoje?`);
//se for igual a sábado;
if (diaSemana == 'Sábado') { 
    alert(`Bom final de semana, ${username}!`);
} else if (diaSemana == 'Domingo') {
    alert(`Bom final de semana, ${username} `);
}else {
    alert(`Boa Semana, ${username}`);
}
let numero = prompt('insira um número')
//se for maior que 0
if (numero >=0) {
    alert('maior que zero')
} else {alert('menor que zero')}